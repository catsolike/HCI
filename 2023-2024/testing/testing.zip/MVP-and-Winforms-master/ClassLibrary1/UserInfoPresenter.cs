﻿namespace ClassLibrary1;

public class UserInfoPresenter
{
    private readonly IUserInfo _form;

    public UserInfoPresenter(IUserInfo form)
    {
        _form = form;
        _form.SaveAttempted += _form_SaveAttempted;
    }

    private void _form_SaveAttempted(object? sender, EventArgs e)
    {
        _form.ShowFormErrors = false;
        _form.ErrorMessage = null;
        // Проверка  имени
        if (string.IsNullOrEmpty(_form.FirstName))
        {
            _form.ShowFormErrors = true;
            _form.ErrorMessage += "\nFirst Name cannot be empty";
        }
        else if (!char.IsUpper(_form.FirstName[0]))
        {
            _form.ShowFormErrors = true;
            _form.ErrorMessage += "\nFirst Name should start with an uppercase letter";
        }
        // Проверка  фамилии

        if (string.IsNullOrEmpty(_form.LastName))
        {
            _form.ShowFormErrors = true;
            _form.ErrorMessage += "\nLast Name cannot be empty";
        }
        else if (!char.IsUpper(_form.LastName[0]))
        {
            _form.ShowFormErrors = true;
            _form.ErrorMessage += "\nLast Name should start with an uppercase letter";
        }
        // Проверка  email
        if (string.IsNullOrEmpty(_form.Email))
        {
            _form.ShowFormErrors = true;
            _form.ErrorMessage += "\nEmail cannot be empty";
        }
        else if (!_form.Email.Contains("@"))
        {
            _form.ShowFormErrors = true;
            _form.ErrorMessage += "\nEmail must contain @ symbol";
        }
        //Проверка телефона
        if (string.IsNullOrEmpty(_form.Phone))
        {
            _form.ShowFormErrors = true;
            _form.ErrorMessage += "\nPhone cannot be empty";
        }
        
        else  if (!_form.Phone.StartsWith("+7") && !_form.Phone.StartsWith("8"))
        {
            _form.ShowFormErrors = true;
            _form.ErrorMessage += "\nPhone number must start with '+7' or '8'";
        }

        //Проверка на проживание
        
        if (string.IsNullOrEmpty(_form.Place) || !_form.Place.Equals("Russia", StringComparison.OrdinalIgnoreCase))
        {
            _form.ShowFormErrors = true;
            _form.ErrorMessage += "\nYou must live in Russia to register";
        }
        //Проверка на пол
        if (string.IsNullOrEmpty(_form.Gender) || (_form.Gender.ToUpper() != "F" && _form.Gender.ToUpper() != "M"))
        {
            _form.ShowFormErrors = true;
            _form.ErrorMessage += "\nPlease select a valid gender (F for female, M for male)";
        }



    }
}